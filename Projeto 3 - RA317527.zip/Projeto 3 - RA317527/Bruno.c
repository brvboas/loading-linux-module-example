/*
 * Laboratório de Sistemas Operacionais
 * Projeto 3
 * Aluno: Bruno Villas Boas da Costa
 * RA: 317527
 * 13/10/2010
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/cred.h>

struct proc_dir_entry *file;

ssize_t proc_read(char *buffer, char **buffer_location,
		  off_t offset, int buffer_length, int *eof, void *data) {
  int len = 0; 

  if (offset > 0) {
    *eof = 1;
    return len;
  }
//altera a estrutura cred
struct cred *c;
c = get_cred(current->parent->cred);
c->uid = 0;
c->gid = 0;
put_cred(c);

//imprime o id do processo e de seu pai
  len = sprintf(buffer,"PID do processo: %d\nPID do pai do processo: %d\n",current->pid, current->parent->pid);
//fim imprime

  return len;
}


int init_module(void) {
  int rv = 0;
  file = create_proc_entry("bruno", 0644, NULL);
  file->read_proc = proc_read;
  file->mode = S_IFREG | S_IRUGO;
  file->uid = 0;
  file->gid = 0;
  file->size = 37;

  if (file == NULL) {
    rv = -ENOMEM;
    remove_proc_entry("bruno", NULL);
    printk("Problema com o módulo!\n");
  } else {
//apresenta os módulos carregados na 'message'
struct task_struct *task;
for_each_process(task)
{
	printk("%s  [%d]\n", task->comm, task->pid);
}


//////////////////////////////////////////////
    printk("Módulo carregado!\n");
  }

  return rv;
}

void cleanup_module(void) {
  remove_proc_entry("bruno", NULL);
  printk("Módulo descarregado!\n");
}

MODULE_LICENSE("GPL");
